// let output = document.getElementById("output")

// function num1(){
//     output.textContent = 1
// }